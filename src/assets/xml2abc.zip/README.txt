THIS IS A CUSTOM VERSION OF THE XML2ABC LIBRARY!

Directions:
1) Download this folder
2) Run npm install https://wim.vree.org/js/xml2abc.tgz in the project to install the base version of xml2abc
3) Replace the files created in node_modules/xml2abc with these
4) Pray

-Colin